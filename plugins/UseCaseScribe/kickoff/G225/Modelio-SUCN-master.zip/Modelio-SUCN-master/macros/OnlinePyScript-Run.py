import onlinepyscript
if 'ONLINE_PY_SCRIPT' not in globals():
    ONLINE_PY_SCRIPT = onlinepyscript.OnlinePyScript(globals())
    
ONLINE_PY_SCRIPT.run()