.. include:: ../plugins/SQLScribe/docs/index.rst

