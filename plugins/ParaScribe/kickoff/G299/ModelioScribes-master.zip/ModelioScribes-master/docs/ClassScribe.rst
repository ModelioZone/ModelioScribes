.. include:: ../plugins/ClassScribe/docs/index.rst

