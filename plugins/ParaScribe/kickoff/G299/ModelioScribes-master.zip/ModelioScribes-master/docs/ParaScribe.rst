.. include:: ../plugins/ParaScribe/docs/index.rst

