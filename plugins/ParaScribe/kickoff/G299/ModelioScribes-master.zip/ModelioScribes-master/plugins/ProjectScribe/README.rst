This directory contains the ProjectScribe plugin for Modelio. The documentation of this plugin is best viewed on http://ModelioScribes.readthedocs.org
