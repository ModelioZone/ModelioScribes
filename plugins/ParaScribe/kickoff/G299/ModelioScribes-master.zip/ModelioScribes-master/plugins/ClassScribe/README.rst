This directory contains the ClassScribe plugin for Modelio. The documentation of this plugin is best viewed on http://ModelioScribes.readthedocs.org
